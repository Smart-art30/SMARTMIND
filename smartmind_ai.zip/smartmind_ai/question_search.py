from django.db.models import Q
from library.models import Question


STOP_WORDS = {
    "what", "is", "are", "the", "a", "an",
    "of", "to", "for", "and", "or", "in",
    "explain", "define", "describe", "tell",
    "about", "please", "show", "give",
}


def clean_query(question):

    words = []

    for word in question.lower().split():

        word = word.strip(".,?!()[]{}:;'\"")

        if len(word) < 3:
            continue

        if word in STOP_WORDS:
            continue

        words.append(word)

    return list(dict.fromkeys(words))


def search_questions(
    question,
    learner_class=None,
    subject=None,
    limit=20,
):
    """
    Search the SmartMind question bank.
    """

    queryset = Question.objects.select_related(
        "level",
        "subject",
        "topic",
        "subtopic",
    )

    if learner_class:
        queryset = queryset.filter(
            level__name__icontains=learner_class
        )

    if subject:
        queryset = queryset.filter(
            subject__name__icontains=subject
        )

    words = clean_query(question)

    query = Q()

    for word in words:

        query |= Q(question__icontains=word)
        query |= Q(topic__title__icontains=word)
        query |= Q(subtopic__title__icontains=word)
        query |= Q(subject__name__icontains=word)

    return queryset.filter(query).distinct()[:limit]


def build_question_context(questions):
    """
    Convert questions into AI context.
    """

    if not questions:
        return ""

    context = []

    for q in questions:

        context.append(
f"""
Question

{q.question}

A. {q.option_a}

B. {q.option_b}

C. {q.option_c}

D. {q.option_d}

Correct Answer:

{q.answer}
"""
        )

    return "\n\n--------------------------\n\n".join(context)