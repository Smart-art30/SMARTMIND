from .search import search_resources, build_context
from .vector_search import vector_search
from .reranker import rerank_resources
from .adaptive import build_adaptive_context
from .quiz import build_quiz_context
from .recommendations import (
    recommend_resources,
    build_recommendation_context,
)
from .progress import build_progress_context


def retrieve_context(question, user, learner_class, intent):
    """
    Retrieve all context for Gemini using Hybrid RAG.
    """

    lesson_context = ""
    question_context = ""
    resources = []

    # ---------------------------------------
    # Lesson Retrieval
    # ---------------------------------------

    if intent == "quiz":

        question_context = build_quiz_context(
            question,
            learner_class,
        )

    else:

        # Keyword Search
        keyword_results = search_resources(
            question=question,
            learner_class=learner_class,
        )

        # Vector Search (FAISS)
        vector_results = vector_search(
            question=question,
            limit=5,   # retrieve more candidates
        )

        # Merge results without duplicates
        seen = set()

        for resource in keyword_results + vector_results:

            if resource.id in seen:
                continue

            seen.add(resource.id)
            resources.append(resource)

        # AI Re-ranking
        resources = rerank_resources(
            question=question,
            resources=resources,
            top_k=2,
        )

        # Build lesson context
        lesson_context = build_context(resources)

    # ---------------------------------------
    # Recommendations
    # ---------------------------------------

    recommendation_context = build_recommendation_context(
        recommend_resources(user)
    )

    # ---------------------------------------
    # Progress
    # ---------------------------------------

    progress_context = build_progress_context(user)

    # ---------------------------------------
    # Adaptive Learning
    # ---------------------------------------

    adaptive_context = build_adaptive_context(user)

    # ---------------------------------------
    # Return everything
    # ---------------------------------------

    return {
        "resources": resources,
        "lesson_context": lesson_context,
        "question_context": question_context,
        "recommendation_context": recommendation_context,
        "progress_context": progress_context,
        "adaptive_context": adaptive_context,
    }