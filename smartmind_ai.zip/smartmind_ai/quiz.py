from .question_search import (
    search_questions,
    build_question_context,
)


def build_quiz_context(
    question,
    learner_class=None,
):

    questions = search_questions(
        question=question,
        learner_class=learner_class,
        limit=20,
    )

    return build_question_context(
        questions
    )