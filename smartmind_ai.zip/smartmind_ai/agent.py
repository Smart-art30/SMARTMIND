from .intents import detect_intent


def choose_tool(question):
    """
    Decide which SmartMind tool should answer.
    """

    intent = detect_intent(question)

    tool_map = {
        "tutor": "tutor",
        "quiz": "quiz",
        "mark": "marker",
        "teacher": "teacher",
        "notes": "notes",
    }

    return tool_map.get(intent, "tutor")