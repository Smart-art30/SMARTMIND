import os

from dotenv import load_dotenv
from google import genai
from .agent import choose_tool
from .memory import (
    save_user_message,
    save_ai_message,
    get_conversation,
)


from .intents import detect_intent
from .rag import retrieve_context

load_dotenv()

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)

SYSTEM_PROMPT = """
You are SmartMind AI, the official tutor for SmartMind Trials.

Use SmartMind lessons first.
Teach clearly.
Adapt to the learner's level.
Explain step by step.
If no lesson exists, answer using accurate knowledge.
"""

def ask_ai(question, user=None):
    """
    Main SmartMind AI Orchestrator.
    """
    simple_replies = {
        "hi": "Hello! 👋 I'm SmartMind AI. How can I help you today?",
        "hello": "Hello! 👋 What would you like to learn today?",
        "hey": "Hi! 👋 Ask me any learning question.",
        "thanks": "You're welcome! 😊",
        "thank you": "You're welcome! 😊",
        "ok": "Alright! What would you like to learn next?",
        "okay": "Alright! What would you like to learn next?",
    }

    reply = simple_replies.get(question.lower().strip())

    if reply:
        save_ai_message(user, reply)
        return reply

    # -----------------------------------
    # Save learner message
    # -----------------------------------

    save_user_message(user, question)

    # -----------------------------------
    # User Information
    # -----------------------------------

    role = "Guest"
    learner_class = None

    if user and user.is_authenticated:
        role = user.role

        if user.school_class:
            learner_class = user.school_class.name

    # -----------------------------------
    # Conversation Memory
    # -----------------------------------

    conversation = ""

    if user and user.is_authenticated:
        conversation = get_conversation(user, limit=2)

    # -----------------------------------
    # Detect Intent
    # -----------------------------------

    intent = detect_intent(question)
    tool = choose_tool(question)

    # -----------------------------------
    # Retrieve SmartMind Context (RAG)
    # -----------------------------------

    context = {
    "resources": [],
    "lesson_context": "",
    "question_context": "",
    "recommendation_context": "",
    "progress_context": "",
    "adaptive_context": "",
     }
                                       

    # Only retrieve RAG when needed
    if intent not in ("greeting", "conversation") and tool in ("tutor", "quiz", "notes"):
        context = retrieve_context(
            question=question,
            user=user,
            learner_class=learner_class,
            intent=intent,
        )

    resources = context["resources"]
    lesson_context = context["lesson_context"]
    question_context = context["question_context"]
    recommendation_context = context["recommendation_context"]
    progress_context = context["progress_context"]
    adaptive_context = context["adaptive_context"]

   

    tool_prompt = ""

    if tool == "tutor":
        tool_prompt = """
You are acting as a SmartMind Tutor.

Teach the learner step by step.
Focus on understanding.
"""

    elif tool == "quiz":
        tool_prompt = """
You are acting as a SmartMind Quiz Generator.

Reuse SmartMind questions whenever possible.

If necessary, generate new CBC-style questions.
Do not reveal answers unless requested.
"""

    elif tool == "teacher":
        tool_prompt = """
You are acting as a Teacher Assistant.

Help teachers create:

- Lesson Plans
- Schemes of Work
- Exams
- Marking Schemes
- Rubrics
- CBC Assessments

Produce professional educational documents.
"""

    elif tool == "marker":
        tool_prompt = """
You are acting as an AI Examiner.

Mark learner work carefully.

Award marks fairly.

Explain mistakes.

Suggest improvements.

Give constructive feedback.
"""

    elif tool == "notes":
        tool_prompt = """
You are acting as a Revision Assistant.

Create:

- Revision Notes
- Summaries
- Flashcards
- Key Points
- Mnemonics

Keep them clear and easy to revise.
"""

    # -----------------------------------
    # Debug
    # -----------------------------------

    print("\n" + "=" * 80)
    print("SMARTMIND HYBRID RAG")
    print("=" * 80)

    print("Question :", question)
    print("Intent   :", intent)
    print("Role     :", role)
    print("Class    :", learner_class)

    print("\nRetrieved Lessons:")

    if resources:
        for i, lesson in enumerate(resources, start=1):
            print("-" * 50)
            print(f"{i}. {lesson.title}")
            if lesson.subject:
                print("Subject :", lesson.subject.name)
            if lesson.topic:
                print("Topic   :", lesson.topic.title)
            if lesson.subtopic:
                print("Subtopic:", lesson.subtopic.title)
    else:
        print("No matching lessons.")

    print("=" * 80)

    # -----------------------------------
    # Build Prompt
    # -----------------------------------

    prompt = f"""
{SYSTEM_PROMPT}

==================================================

PERSONALISED LEARNING PLAN

{adaptive_context if adaptive_context else "No recommendations available."}

==================================================

LEARNER INFORMATION

Role:
{role}

Class:
{learner_class if learner_class else "Unknown"}

==================================================

AI TASK

Intent:
{intent}

Selected Tool:
{tool}

Tool Instructions:

{tool_prompt}

==================================================

PREVIOUS CONVERSATION

{conversation if conversation else "No previous conversation."}

==================================================

LEARNER PROGRESS

{progress_context if progress_context else "No progress available."}

==================================================

RECOMMENDED LESSONS

{recommendation_context if recommendation_context else "No recommendations available."}

==================================================

SMARTMIND KNOWLEDGE BASE
(Hybrid Retrieval: Semantic Search + Keyword Search)

{lesson_context if lesson_context else "No matching lessons found."}

==================================================

SMARTMIND QUESTION BANK

{question_context if question_context else "No matching questions found."}

==================================================

LEARNER QUESTION

{question}

==================================================

INSTRUCTIONS

1. Continue naturally from the previous conversation.
2. Treat SmartMind Knowledge Base as the primary source of truth.
3. The retrieved lessons came from semantic and keyword search.
4. If several lessons are related, combine them into one explanation.
5. Use learner progress to personalise your response.
6. Recommend additional lessons where appropriate.
7. If lesson notes are incomplete, supplement with accurate knowledge.
8. If the intent is "quiz", reuse SmartMind questions before generating new ones.
9. Adapt explanations to the learner's class.
10. Show all mathematics step by step.
11. Use headings, tables and bullet points where appropriate.
12. If SmartMind contains no matching lesson, answer accurately using your own knowledge.

Begin your response.
"""

    # -----------------------------------
    # Gemini
    # -----------------------------------

    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
        )

        answer = response.text.strip()

    except Exception as e:
        answer = (
            "Sorry, SmartMind AI is temporarily unavailable.\n\n"
            f"Technical details:\n{str(e)}"
        )

    # -----------------------------------
    # Save AI Response
    # -----------------------------------

    save_ai_message(user, answer)

    return answer