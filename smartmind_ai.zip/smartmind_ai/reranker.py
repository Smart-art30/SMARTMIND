import json

from google import genai
from dotenv import load_dotenv
import os

load_dotenv()

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)


def rerank_resources(question, resources, top_k=5):
    """
    Uses Gemini to choose the most relevant resources.
    """

    if len(resources) <= top_k:
        return resources

    prompt = f"""
A student asked:

{question}

Below are SmartMind lesson titles.

Choose the {top_k} most relevant lessons.

Return ONLY a JSON list of lesson numbers.

Example:

[2,5,7]

Lessons:

"""

    for i, r in enumerate(resources, start=1):

        prompt += f"""

{i}.

Title:
{r.title}

Subject:
{r.subject}

Topic:
{r.topic}

Subtopic:
{r.subtopic}

"""

    try:

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
        )

        indexes = json.loads(response.text)

        selected = []

        for i in indexes:

            if 1 <= i <= len(resources):
                selected.append(resources[i - 1])

        return selected

    except Exception:

        return resources[:top_k]