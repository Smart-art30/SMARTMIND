from django.db.models import Q

from library.models import (
    Resource,
    Question,
)


STOP_WORDS = {
    "what",
    "how",
    "why",
    "where",
    "when",
    "who",
    "is",
    "are",
    "was",
    "were",
    "the",
    "a",
    "an",
    "of",
    "to",
    "for",
    "about",
    "explain",
    "teach",
    "define",
}

SYNONYMS = {

    "food": [
        "photosynthesis",
    ],

    "force": [
        "newton",
        "motion",
    ],

    "cells": [
        "cell",
        "biology",
    ],

    "acid": [
        "acids",
        "bases",
        "ph",
    ],
}

def clean_question(question):
    words = []

    for word in question.lower().split():

        word = word.strip(".,?!()[]{}")

        if len(word) < 3:
            continue

        if word in STOP_WORDS:
            continue

        words.append(word)

    return words


def search_library(question, limit=10):

    words = clean_question(question)

    query = Q()

    for word in words:

        query |= Q(title__icontains=word)
        query |= Q(description__icontains=word)
        query |= Q(topic__title__icontains=word)
        query |= Q(subtopic__title__icontains=word)
        query |= Q(subject__name__icontains=word)

    resources = (
        Resource.objects
        .filter(query)
        .distinct()[:limit]
    )

    questions = (
        Question.objects
        .filter(query)
        .distinct()[:limit]
    )

    return resources, questions