import os
import numpy as np
from sentence_transformers import SentenceTransformer

# Load once when Django starts
MODEL = SentenceTransformer("all-MiniLM-L6-v2")

def build_resource_text(resource):
    """
    Convert a Resource into searchable text.
    """

    parts = []

    if resource.subject:
        parts.append(f"Subject: {resource.subject.name}")

    if resource.topic:
        parts.append(f"Topic: {resource.topic.title}")

    if resource.subtopic:
        parts.append(f"Subtopic: {resource.subtopic.title}")

    if resource.title:
        parts.append(f"Title: {resource.title}")

    if resource.description:
        parts.append(f"Description: {resource.description}")

    # Most important
    if resource.content:
        parts.append(f"Content: {resource.content}")

    return "\n\n".join(parts)


def create_embedding(text):
    vector = MODEL.encode(
        text,
        normalize_embeddings=True,
        convert_to_numpy=True,
    )

    return np.asarray(vector, dtype="float32")


def embed_resource(resource):
    """
    Create an embedding for one Resource.
    """

    text = build_resource_text(resource)

    return create_embedding(text)